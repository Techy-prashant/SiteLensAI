"""
SiteLens AI — Speech-to-Text Engine (Groq Whisper)

Transcribes audio from worker smart glasses using Groq's
ultra-fast Whisper API.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

import httpx

from app.config import Settings, get_settings

logger = logging.getLogger("sitelens.stt")


class GroqSTTEngine:
    """Groq Whisper API backend for speech-to-text."""

    API_URL = "https://api.groq.com/openai/v1/audio/transcriptions"

    def __init__(self, settings: Settings):
        if not settings.groq_api_key:
            raise ValueError("GROQ_API_KEY must be set for Groq STT engine.")
        self.api_key = settings.groq_api_key
        self.model = "whisper-large-v3-turbo"
        self._client = httpx.AsyncClient(timeout=30.0)
        logger.info("Groq STT engine initialized (model=%s)", self.model)

    async def transcribe(
        self,
        audio_bytes: bytes,
        filename: str = "audio.wav",
        language: str = "en",
    ) -> dict[str, Any]:
        """
        Transcribe audio bytes to text.

        Returns dict with keys: text, language, duration
        """
        files = {
            "file": (filename, audio_bytes, "audio/wav"),
        }
        data = {
            "model": self.model,
            "language": language,
            "response_format": "verbose_json",
        }

        try:
            resp = await self._client.post(
                self.API_URL,
                headers={"Authorization": f"Bearer {self.api_key}"},
                files=files,
                data=data,
            )
            resp.raise_for_status()
        except httpx.HTTPStatusError as e:
            logger.error("Groq STT error %s: %s", e.response.status_code, e.response.text)
            raise e

        result = resp.json()
        text = result.get("text", "").strip()
        logger.info("Transcribed %d chars: '%.80s...'", len(text), text)

        return {
            "text": text,
            "language": result.get("language", language),
            "duration": result.get("duration", 0),
        }


def create_stt_engine(settings: Settings | None = None) -> GroqSTTEngine:
    """Factory to create the STT engine."""
    settings = settings or get_settings()
    return GroqSTTEngine(settings)
