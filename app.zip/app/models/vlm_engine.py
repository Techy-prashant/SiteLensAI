"""
SiteLens AI — VLM Engine (Multi-Backend)

Provides a unified interface for vision-language analysis across:
  • Ollama  (local Qwen3-VL)
  • Grok    (xAI cloud API)
  • HuggingFace Transformers (legacy fallback)
"""

from __future__ import annotations

import abc
import base64
import io
import json
import logging
from typing import Any, Optional

import httpx
from PIL import Image

from app.config import Settings, VLMBackend, get_settings

logger = logging.getLogger("sitelens.vlm")


# ── Construction-site analysis prompt (shared) ──────────────────────────

CONSTRUCTION_ANALYSIS_PROMPT = """Analyze this construction site image for safety hazards.

Identify ALL of the following if present:
1. **Fall Risks**: Workers near edges without harnesses, open ledges, unguarded holes, scaffolding issues
2. **Heavy Machinery Hazards**: Crane loads, moving equipment near workers, improperly rigged loads
3. **Electrical Hazards**: Exposed wiring, workers near power lines, damaged cables
4. **PPE Violations** — CHECK EVERY VISIBLE PERSON individually:
   - Hard hat / helmet: is each person wearing one?
   - Hi-vis / reflective safety vest: is each person wearing one?
   - Safety glasses or goggles: required in active work areas
   - Gloves: required when handling materials or tools
   - Safety boots: required on all construction sites
   If ANY person is missing ANY item of PPE, you MUST report it as a PPE Breach hazard.
5. **Structural Risks**: Sagging beams, unstable stacking, trench collapse indicators
6. **General Hazards**: Blocked exits, improper material storage, housekeeping issues

For each hazard found, specify:
- Type of hazard
- Location in the scene (left/right/center/foreground/background)
- Estimated severity (CRITICAL / WARNING / INFO)
- Whether a worker is in immediate danger

MANDATORY: For the "ppe_compliance" field, describe SPECIFICALLY what PPE each visible person
IS and IS NOT wearing. Do NOT just say "compliant". List missing items explicitly, e.g.
"Worker in foreground not wearing hard hat or hi-vis vest."

Respond ONLY with valid JSON in this exact format:
{
  "scene_description": "Brief description of the construction scene",
  "hazards_found": [
    {
      "type": "Fall Risk | Heavy Machinery | Electrical | PPE Breach | Structural | General",
      "description": "What exactly is the hazard",
      "location": "Where in the scene",
      "severity": "CRITICAL | WARNING | INFO",
      "worker_in_danger": true | false
    }
  ],
  "overall_risk_level": "CRITICAL | WARNING | INFO | NONE",
  "worker_count": 0,
  "ppe_compliance": "Detailed per-person PPE status. List every missing item."
}"""



# ── Base class ───────────────────────────────────────────────────────────

class VLMEngine(abc.ABC):
    """Abstract base for VLM backends."""

    @abc.abstractmethod
    async def analyze_frame(
        self,
        image_bytes: bytes,
        prompt: str | None = None,
    ) -> dict[str, Any]:
        """
        Analyze a single image frame and return structured JSON.

        Parameters
        ----------
        image_bytes : raw JPEG/PNG bytes
        prompt : optional override for the analysis prompt

        Returns
        -------
        Parsed JSON dict from the VLM.
        """
        ...

    # ── helpers ──

    @staticmethod
    def _image_to_base64(image_bytes: bytes, max_size: int = 1024) -> str:
        """Convert image to base64, standardizing format to JPEG and restricting size."""
        try:
            image = Image.open(io.BytesIO(image_bytes))
            if image.mode != "RGB":
                image = image.convert("RGB")
            
            if max(image.size) > max_size:
                image.thumbnail((max_size, max_size), Image.Resampling.LANCZOS)
                
            buffer = io.BytesIO()
            image.save(buffer, format="JPEG", quality=85)
            return base64.b64encode(buffer.getvalue()).decode("utf-8")
        except Exception as e:
            logger.warning("Image preprocessing failed, using raw bytes: %s", e)
            return base64.b64encode(image_bytes).decode("utf-8")

    @staticmethod
    def _parse_json_response(text: str) -> dict[str, Any]:
        """Best-effort JSON extraction from LLM output."""
        res = None

        # Try direct parse first
        try:
            res = json.loads(text)
        except json.JSONDecodeError:
            pass

        if not isinstance(res, dict):
            res = None

        # Find JSON block in markdown fences
        if res is None:
            for marker in ("```json", "```"):
                if marker in text:
                    start = text.index(marker) + len(marker)
                    end = text.index("```", start)
                    try:
                        parsed = json.loads(text[start:end].strip())
                        if isinstance(parsed, dict):
                            res = parsed
                            break
                    except (json.JSONDecodeError, ValueError):
                        pass

        # Find first { ... } block
        if res is None:
            brace_start = text.find("{")
            brace_end = text.rfind("}") + 1
            if brace_start != -1 and brace_end > brace_start:
                try:
                    parsed = json.loads(text[brace_start:brace_end])
                    if isinstance(parsed, dict):
                        res = parsed
                except json.JSONDecodeError:
                    pass

        # Fallback: return raw text wrapped in a dict
        if res is None:
            logger.warning("Could not parse VLM JSON — returning raw text.")
            res = {
                "scene_description": text[:500],
                "hazards_found": [],
                "overall_risk_level": "INFO",
                "worker_count": 0,
                "ppe_compliance": "Unable to parse structured response",
            }

        res["raw_model_response"] = text
        return res


# ── Grok (xAI Cloud) ────────────────────────────────────────────────────

class GrokVLM(VLMEngine):
    """xAI Grok vision API backend."""

    API_URL = "https://api.x.ai/v1/chat/completions"

    def __init__(self, settings: Settings):
        if not settings.grok_api_key:
            raise ValueError("GROK_API_KEY must be set for Grok VLM backend.")
        self.api_key = settings.grok_api_key
        self.model = settings.grok_model
        self._client = httpx.AsyncClient(timeout=60.0)

    async def analyze_frame(
        self,
        image_bytes: bytes,
        prompt: str | None = None,
    ) -> dict[str, Any]:
        b64 = self._image_to_base64(image_bytes)
        prompt = prompt or CONSTRUCTION_ANALYSIS_PROMPT

        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{b64}",
                            },
                        },
                        {"type": "text", "text": prompt},
                    ],
                }
            ],
            "max_tokens": 1024,
            "temperature": 0.3,
        }

        try:
            resp = await self._client.post(
                self.API_URL,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json=payload,
            )
            resp.raise_for_status()
        except httpx.HTTPStatusError as e:
            logger.error("Grok API error %s: %s", e.response.status_code, e.response.text)
            raise e
        data = resp.json()

        raw_text = data["choices"][0]["message"]["content"]
        logger.debug("Grok raw response: %s", raw_text[:300])
        return self._parse_json_response(raw_text)


# ── Groq (Ultra-fast LPU inference) ─────────────────────────────────────

class GroqVLM(VLMEngine):
    """Groq API backend for fast vision models."""

    API_URL = "https://api.groq.com/openai/v1/chat/completions"

    def __init__(self, settings: Settings):
        if not settings.groq_api_key:
            raise ValueError("GROQ_API_KEY must be set for Groq VLM backend.")
        self.api_key = settings.groq_api_key
        self.model = settings.groq_model
        self._client = httpx.AsyncClient(timeout=60.0)

    async def analyze_frame(
        self,
        image_bytes: bytes,
        prompt: str | None = None,
    ) -> dict[str, Any]:
        b64 = self._image_to_base64(image_bytes)
        prompt = prompt or CONSTRUCTION_ANALYSIS_PROMPT

        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{b64}",
                            },
                        },
                        {"type": "text", "text": prompt},
                    ],
                }
            ],
            "max_tokens": 1024,
            "temperature": 0.3,
        }

        try:
            resp = await self._client.post(
                self.API_URL,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json=payload,
            )
            resp.raise_for_status()
        except httpx.HTTPStatusError as e:
            logger.error("Groq API error %s: %s", e.response.status_code, e.response.text)
            raise e
        data = resp.json()

        raw_text = data["choices"][0]["message"]["content"]
        logger.debug("Groq raw response: %s", raw_text[:300])
        return self._parse_json_response(raw_text)


# ── Ollama (Local) ───────────────────────────────────────────────────────

class OllamaVLM(VLMEngine):
    """Local Ollama backend (Qwen3-VL)."""

    def __init__(self, settings: Settings):
        self.host = settings.ollama_host.rstrip("/")
        self.model = settings.ollama_model
        self._client = httpx.AsyncClient(timeout=120.0)

    async def analyze_frame(
        self,
        image_bytes: bytes,
        prompt: str | None = None,
    ) -> dict[str, Any]:
        b64 = self._image_to_base64(image_bytes)
        prompt = prompt or CONSTRUCTION_ANALYSIS_PROMPT

        payload = {
            "model": self.model,
            "prompt": prompt,
            "images": [b64],
            "stream": False,
            "options": {
                "temperature": 0.3,
                "num_predict": 1024,
            },
        }

        resp = await self._client.post(
            f"{self.host}/api/generate",
            json=payload,
        )
        resp.raise_for_status()
        raw_text = resp.json().get("response", "")
        logger.debug("Ollama raw response: %s", raw_text[:300])
        return self._parse_json_response(raw_text)


# ── HuggingFace Transformers (Legacy fallback) ──────────────────────────

class TransformersVLM(VLMEngine):
    """
    Local HuggingFace Transformers backend using Qwen2-VL-2B-Instruct.
    This preserves compatibility with the original environment_scan.py.
    """

    def __init__(self, settings: Settings):
        import torch
        from transformers import AutoProcessor, Qwen2VLForConditionalGeneration

        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        dtype = torch.float16 if self.device == "cuda" else torch.float32

        logger.info("Loading Qwen2-VL-2B-Instruct (Transformers)…")
        self.model = Qwen2VLForConditionalGeneration.from_pretrained(
            "Qwen/Qwen2-VL-2B-Instruct",
            torch_dtype=dtype,
            device_map="auto",
            trust_remote_code=True,
        )
        self.processor = AutoProcessor.from_pretrained(
            "Qwen/Qwen2-VL-2B-Instruct",
            trust_remote_code=True,
        )
        self.model.eval()
        logger.info("Qwen2-VL loaded on %s.", self.device)

    async def analyze_frame(
        self,
        image_bytes: bytes,
        prompt: str | None = None,
    ) -> dict[str, Any]:
        import torch

        prompt = prompt or CONSTRUCTION_ANALYSIS_PROMPT
        image = Image.open(io.BytesIO(image_bytes)).convert("RGB")

        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image"},
                    {"type": "text", "text": prompt},
                ],
            }
        ]

        text = self.processor.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True
        )
        inputs = self.processor(
            text=[text], images=[image], return_tensors="pt"
        ).to(self.device)

        with torch.no_grad():
            output_ids = self.model.generate(
                **inputs,
                max_new_tokens=1024,
                temperature=0.3,
                do_sample=True,
            )

        raw_text = self.processor.batch_decode(
            output_ids,
            skip_special_tokens=True,
            clean_up_tokenization_spaces=True,
        )[0]

        # Strip the prompt echo
        if prompt in raw_text:
            raw_text = raw_text.split(prompt)[-1].strip()

        logger.debug("Transformers raw response: %s", raw_text[:300])
        return self._parse_json_response(raw_text)


# ── Factory ──────────────────────────────────────────────────────────────

def create_vlm_engine(settings: Settings | None = None) -> VLMEngine:
    """Instantiate the correct VLM engine based on configuration."""
    settings = settings or get_settings()

    match settings.vlm_backend:
        case VLMBackend.GROK:
            logger.info("Initializing Grok VLM engine (model=%s)", settings.grok_model)
            return GrokVLM(settings)
        case VLMBackend.GROQ:
            logger.info("Initializing Groq VLM engine (model=%s)", settings.groq_model)
            return GroqVLM(settings)
        case VLMBackend.OLLAMA:
            logger.info("Initializing Ollama VLM engine (model=%s)", settings.ollama_model)
            return OllamaVLM(settings)
        case VLMBackend.TRANSFORMERS:
            logger.info("Initializing Transformers VLM engine")
            return TransformersVLM(settings)
        case _:
            raise ValueError(f"Unknown VLM backend: {settings.vlm_backend}")
