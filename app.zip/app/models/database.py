"""
SiteLens AI — Audit Database (SQLite)

Stores incidents, compliance violations, and audit logs.
Uses aiosqlite for async compatibility with FastAPI.

Designed to be swappable with Supabase PostgreSQL in production.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from uuid import uuid4

import aiosqlite

logger = logging.getLogger("sitelens.database")

DB_PATH = Path(__file__).resolve().parent.parent.parent / "data" / "sitelens_audit.db"


class AuditDatabase:
    """Async SQLite database for audit logging."""

    def __init__(self, db_path: str | Path | None = None):
        self.db_path = Path(db_path) if db_path else DB_PATH
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

    async def initialize(self):
        """Create tables if they don't exist."""
        async with aiosqlite.connect(str(self.db_path)) as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS incidents (
                    id TEXT PRIMARY KEY,
                    timestamp TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    hazard_type TEXT NOT NULL,
                    description TEXT,
                    location TEXT,
                    worker_in_danger INTEGER DEFAULT 0,
                    scene_description TEXT,
                    worker_count INTEGER DEFAULT 0,
                    escalated INTEGER DEFAULT 0,
                    decision TEXT,
                    sop_reference TEXT,
                    audio_alert_text TEXT,
                    processing_time_ms INTEGER DEFAULT 0,
                    metadata TEXT
                )
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS audit_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    severity TEXT,
                    details TEXT,
                    source TEXT DEFAULT 'system'
                )
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS compliance_violations (
                    id TEXT PRIMARY KEY,
                    incident_id TEXT,
                    timestamp TEXT NOT NULL,
                    violation_type TEXT NOT NULL,
                    description TEXT,
                    osha_reference TEXT,
                    resolved INTEGER DEFAULT 0,
                    resolved_at TEXT,
                    FOREIGN KEY (incident_id) REFERENCES incidents(id)
                )
            """)
            await db.commit()
            logger.info("Audit database initialized at %s", self.db_path)

    async def log_incident(self, alert_data: dict[str, Any]) -> str:
        """Log a hazard detection incident. Returns incident ID."""
        incident_id = alert_data.get("alert_id", uuid4().hex[:12])
        now = datetime.now(timezone.utc).isoformat()

        async with aiosqlite.connect(str(self.db_path)) as db:
            await db.execute(
                """INSERT OR REPLACE INTO incidents
                   (id, timestamp, severity, hazard_type, description,
                    location, worker_in_danger, scene_description,
                    worker_count, escalated, decision, sop_reference,
                    audio_alert_text, processing_time_ms, metadata)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    incident_id,
                    alert_data.get("timestamp", now),
                    alert_data.get("severity_level", "NONE"),
                    alert_data.get("hazard_type", "General"),
                    alert_data.get("hazards_detail", [{}])[0].get("description", "") if alert_data.get("hazards_detail") else "",
                    alert_data.get("hazards_detail", [{}])[0].get("location", "") if alert_data.get("hazards_detail") else "",
                    1 if any(h.get("worker_in_danger") for h in alert_data.get("hazards_detail", [])) else 0,
                    alert_data.get("scene_description", ""),
                    alert_data.get("worker_count", 0),
                    1 if alert_data.get("escalate_to_supervisor") else 0,
                    alert_data.get("decision", ""),
                    alert_data.get("sop_reference", ""),
                    alert_data.get("audio_alert_text", ""),
                    alert_data.get("processing_time_ms", 0),
                    json.dumps(alert_data.get("hazards_detail", [])),
                ),
            )

            # Also log to audit trail
            await db.execute(
                """INSERT INTO audit_log (timestamp, event_type, severity, details, source)
                   VALUES (?, ?, ?, ?, ?)""",
                (
                    now,
                    "HAZARD_DETECTED",
                    alert_data.get("severity_level", "NONE"),
                    json.dumps({"incident_id": incident_id, "hazard_type": alert_data.get("hazard_type")}),
                    "vlm_pipeline",
                ),
            )

            # Log compliance violation if severity is WARNING or CRITICAL
            severity = alert_data.get("severity_level", "NONE")
            if severity in ("CRITICAL", "WARNING"):
                violation_id = uuid4().hex[:12]
                await db.execute(
                    """INSERT INTO compliance_violations
                       (id, incident_id, timestamp, violation_type, description, osha_reference)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (
                        violation_id,
                        incident_id,
                        now,
                        alert_data.get("hazard_type", "General"),
                        alert_data.get("audio_alert_text", ""),
                        alert_data.get("sop_reference", ""),
                    ),
                )

            await db.commit()

        logger.info("Logged incident %s (severity=%s)", incident_id, severity)
        return incident_id

    async def get_incidents(
        self,
        limit: int = 50,
        severity: Optional[str] = None,
        hazard_type: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """Retrieve incidents with optional filters."""
        query = "SELECT * FROM incidents"
        params = []
        conditions = []

        if severity:
            conditions.append("severity = ?")
            params.append(severity.upper())
        if hazard_type:
            conditions.append("hazard_type = ?")
            params.append(hazard_type)

        if conditions:
            query += " WHERE " + " AND ".join(conditions)
        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        async with aiosqlite.connect(str(self.db_path)) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(query, params)
            rows = await cursor.fetchall()
            return [dict(row) for row in rows]

    async def get_incident(self, incident_id: str) -> Optional[dict[str, Any]]:
        """Get a single incident by ID."""
        async with aiosqlite.connect(str(self.db_path)) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute("SELECT * FROM incidents WHERE id = ?", (incident_id,))
            row = await cursor.fetchone()
            return dict(row) if row else None

    async def get_compliance_report(self) -> dict[str, Any]:
        """Generate a compliance summary report."""
        async with aiosqlite.connect(str(self.db_path)) as db:
            # Total incidents by severity
            cursor = await db.execute(
                "SELECT severity, COUNT(*) as count FROM incidents GROUP BY severity"
            )
            by_severity = {row[0]: row[1] for row in await cursor.fetchall()}

            # Total incidents by type
            cursor = await db.execute(
                "SELECT hazard_type, COUNT(*) as count FROM incidents GROUP BY hazard_type ORDER BY count DESC"
            )
            by_type = {row[0]: row[1] for row in await cursor.fetchall()}

            # Unresolved violations
            cursor = await db.execute(
                "SELECT COUNT(*) FROM compliance_violations WHERE resolved = 0"
            )
            unresolved = (await cursor.fetchone())[0]

            # Total incidents
            cursor = await db.execute("SELECT COUNT(*) FROM incidents")
            total = (await cursor.fetchone())[0]

            # Escalation rate
            cursor = await db.execute("SELECT COUNT(*) FROM incidents WHERE escalated = 1")
            escalated = (await cursor.fetchone())[0]

            return {
                "total_incidents": total,
                "by_severity": by_severity,
                "by_hazard_type": by_type,
                "unresolved_violations": unresolved,
                "escalation_count": escalated,
                "escalation_rate": round(escalated / max(total, 1) * 100, 1),
                "generated_at": datetime.now(timezone.utc).isoformat(),
            }

    async def log_event(self, event_type: str, severity: str = "INFO", details: str = "", source: str = "system"):
        """Log a generic audit event."""
        async with aiosqlite.connect(str(self.db_path)) as db:
            await db.execute(
                """INSERT INTO audit_log (timestamp, event_type, severity, details, source)
                   VALUES (?, ?, ?, ?, ?)""",
                (datetime.now(timezone.utc).isoformat(), event_type, severity, details, source),
            )
            await db.commit()
